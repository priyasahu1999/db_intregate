<?php 
// $_POST = (file_get_contents('php://input'));
//     print_r((array)$_POST);
//     echo ($_POST);
//     $arr = [];
//     $arr[sizeof($arr)] = $_POST;    

//     header("Content-Type: application/json");
//     echo json_encode($arr[sizeof($arr) - 1]);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

header("Content-Type: application/json");

set_time_limit(3600);
 
$data = json_decode(file_get_contents("php://input"));
$data= json_decode( json_encode($data), true);
foreach ($data as $row) {
        // get the employee details
        $name = htmlspecialchars($row['name']);
        $contact = htmlspecialchars($row['contact']);
        $email = htmlspecialchars($row['email']);
        $speciality = htmlspecialchars($row['speciality']);
        $state = htmlspecialchars($row['state']);
        $city = htmlspecialchars($row['city']);
        $other = htmlspecialchars($row['other']);
       
        $sql = "INSERT INTO `page_users`(`name`,`contact`,`email`,`speciality`,`state`,`city`,`other`) VALUES ('$name','$contact','$email','$speciality','$state','$city','$other')";

      if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
      } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
      }
    }
// $studentname = $data['name'];
// $email = $data['email'];
// echo var_dump($studentname);
//  echo json_encode($data);
// echo "Hello $studentname, your email is $email";

// $sql = "INSERT INTO allergy (name, email)
// VALUES ('$studentname','$email')";
// if ($conn->query($sql) === TRUE) {
//   echo "New record created successfully";
// } else {
//   echo "Error: " . $sql . "<br>" . $conn->error;
// }
$conn->close();
?>