<!DOCTYPE html>
<html>
<head>
    <title>Read Text File</title>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.13.5/xlsx.full.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.13.5/jszip.js"></script>
</head>
<body>
    <input type="file" name="inputfile"
            id="inputfile">
    <br>
    <pre id="output"></pre>
    <div id="ExcelTable"></div>
    <script type="text/javascript">
        document.getElementById('inputfile')
            .addEventListener('change', function() {
            var fr=new FileReader();
            fr.onload=function (e) {
                        var data = "";
                        var bytes = new Uint8Array(e.target.result);
                        for (var i = 0; i < bytes.byteLength; i++) {
                            data += String.fromCharCode(bytes[i]);
                        }
                        GetTableFromExcel(data);
                        var workbook = XLSX.read(data, {
                                type: 'binary'});
                        workbook.SheetNames.forEach(function(sheetName) {
                        // Here is your object
                        var XL_row_object = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]);
                        var send_data = JSON.stringify(XL_row_object);


                        sendJSON(send_data);
                        // var json_object = JSON.stringify(XL_row_object);
                       // alert(json_object);
                        })
                    };
            fr.readAsArrayBuffer(this.files[0]);
        });
        function GetTableFromExcel(data) {
        //Read the Excel File data in binary
        var workbook = XLSX.read(data, {
            type: 'binary'
        });
        //get the name of First Sheet.
        var Sheet = workbook.SheetNames[0];
        //Read all rows from First Sheet into an JSON array.
        var excelRows = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[Sheet]);
        //Create a HTML Table element.
        var myTable  = document.createElement("table");
        myTable.border = "1";
        //Add the header row.
        var row = myTable.insertRow(-1);
        //Add the header cells.
        var headerCell = document.createElement("TH");
        headerCell.innerHTML = "name";
        row.appendChild(headerCell);
        var headerCell = document.createElement("TH");
         headerCell.innerHTML = "contact";
        row.appendChild(headerCell);
        var headerCell = document.createElement("TH");
         headerCell.innerHTML = "email";
        row.appendChild(headerCell);
        var headerCell = document.createElement("TH");
         headerCell.innerHTML = "speciality";
        row.appendChild(headerCell);
        var headerCell = document.createElement("TH");
         headerCell.innerHTML = "state";
        row.appendChild(headerCell);
        var headerCell = document.createElement("TH");
         headerCell.innerHTML = "city";
        row.appendChild(headerCell);
        var headerCell = document.createElement("TH");
         headerCell.innerHTML = "other";
        row.appendChild(headerCell);
        //Add the data rows from Excel file.
        for (var i = 0; i < excelRows.length; i++) { 
            i==0 &&console.log(excelRows[i]);
            //Add the data row.
            var row = myTable.insertRow(-1);
            //Add the data cells.
            var cell = row.insertCell(-1);
            cell.innerHTML = excelRows[i].name;
            var cell = row.insertCell(-1);
            cell.innerHTML = excelRows[i].contact;
            var cell = row.insertCell(-1);
            cell.innerHTML = excelRows[i].email;
            var cell = row.insertCell(-1);
            cell.innerHTML = excelRows[i].speciality;
            var cell = row.insertCell(-1);
            cell.innerHTML = excelRows[i].state;
            var cell = row.insertCell(-1);
            cell.innerHTML = excelRows[i].city;
            var cell = row.insertCell(-1);
            cell.innerHTML = excelRows[i].other;
        }
        var ExcelTable = document.getElementById("ExcelTable");
        ExcelTable.innerHTML = "";
        ExcelTable.appendChild(myTable);
    };
    function sendJSON(send_data){
        console.log(send_data.length)
              let result = document.querySelector('#output');
            //   let name = document.querySelector('#name');
            //   let email = document.querySelector('#email');
              // Creating a XHR object
              let xhr = new XMLHttpRequest();
              let url = "upload.php";
              // open a connection
              xhr.open("POST", url, true);
              // Set the request header i.e. which type of content you are sending
              xhr.setRequestHeader("Content-Type", "application/json");
              // Create a state change callback
              xhr.onreadystatechange = function () {
                  if (xhr.readyState === 4 && xhr.status === 200) {
                      // Print received data from server
                      result.innerHTML = this.responseText;
                  }
              };
              // Converting JSON data to string
            //   var data = JSON.stringify(XL_row_object);
              // Sending data with the request
              xhr.send(send_data);
          }
    </script>
</body>
</html>